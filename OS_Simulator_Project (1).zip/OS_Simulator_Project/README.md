# AmigOS — Operating System Simulator
### CS2006 Operating Systems Lab | Spring 2026 | FAST-NUCES

---

## What is AmigOS?

AmigOS is a terminal-based operating system simulator written in C for Linux/Ubuntu.
It demonstrates all major OS concepts: process management, CPU scheduling, memory
management, synchronisation, user/kernel modes, and multitasking using real Linux
system calls — not just theory.

---

## Team Members

| Member | Role |
|--------|------|
| Member 1 | Core OS, Boot, Resource Manager, Kernel |
| Member 2 | Scheduler, Synchronisation, Ready Queue |
| Member 3 | All 20 Application Tasks |

---

## Requirements

- Ubuntu (or WSL2 on Windows)
- GCC compiler
- make

Install all at once:
```
sudo apt update && sudo apt install gcc make -y
```

Optional (for separate task windows):
```
sudo apt install xterm -y
```

---

## Project Structure

```
OS_Simulator/
├── os.c                  ← Main OS entry point, boot screen, UI, task launcher
├── process.h             ← Process Control Block (PCB) struct definition
├── resource_manager.c/h  ← RAM, HDD tracking using POSIX shared memory
├── scheduler.c/h         ← Multilevel Queue Scheduler (RR + FCFS + Priority)
├── kernel.c/h            ← Kernel/User mode, process table, fork+exec
├── Makefile              ← Builds everything with one command
└── tasks/
    ├── calculator.c      ← [FG]  Basic calculator
    ├── notepad.c         ← [FG]  Text editor with auto-save thread
    ├── file_manager.c    ← [FG]  Create/copy/move/delete/info files
    ├── text_search.c     ← [FG]  Search patterns in files
    ├── rng.c             ← [FG]  Random number generator + dice
    ├── word_count.c      ← [FG]  Count lines/words/chars in file
    ├── encryptor.c       ← [FG]  XOR file encrypt/decrypt
    ├── timer.c           ← [FG]  Named countdown timers
    ├── minesweeper.c     ← [FG]  Minesweeper game
    ├── snake.c           ← [FG]  Snake game (WASD)
    ├── music.c           ← [BG]  Background music simulation
    ├── print_sim.c       ← [BG]  Print job simulation
    ├── log_gen.c         ← [BG]  System log generator
    ├── auto_backup.c     ← [BG]  Auto-backup files every 30s
    ├── disk_cleaner.c    ← [BG]  Remove temp/backup files
    ├── clock.c           ← [SYS] Real-time clock
    ├── calendar.c        ← [SYS] Monthly calendar
    ├── ram_viewer.c      ← [SYS] Live RAM usage bar
    ├── proc_viewer.c     ← [SYS] List running processes
    └── sysinfo.c         ← [SYS] Hardware and OS info
```
FG = Foreground | BG = Background | SYS = System

---

## How to Build

Step 1 — Go into the project folder:
```
cd OS_Simulator
```

Step 2 — Compile everything:
```
make
```

Step 3 — Run AmigOS:
```
./OS 2048 256000 8
```

Arguments: RAM in MB, HDD in MB, Number of CPU cores

To clean and rebuild from scratch:
```
make clean
make
```

---

## How to Use

When AmigOS starts you will see:
1. Boot screen with loading animation
2. Main menu showing all 20 tasks + resource bar

Type a number (1-20) to launch a task.
Type 'exit' inside any task to return to the main menu.

### Main Menu Commands

| Command    | What it does                          |
|------------|---------------------------------------|
| 1 - 20     | Launch that task                      |
| ps         | Show all running processes            |
| res        | Show RAM and HDD usage                |
| q          | Show scheduler ready queue            |
| kernel     | Enter kernel mode (password: admin)   |
| shutdown   | Shut down AmigOS                      |

### Kernel Mode Commands (password: admin)

| Command    | What it does                          |
|------------|---------------------------------------|
| list       | List all processes with full details  |
| kill N     | Kill process with internal ID N       |
| min N      | Minimize (pause) process ID N         |
| res N      | Restore minimized process ID N        |
| mem        | Show memory status                    |
| exit       | Return to user mode                   |

---

## OS Concepts Implemented

| Concept                     | How it is implemented                                      |
|-----------------------------|------------------------------------------------------------|
| Process Creation            | fork() + exec() — each task is a real Linux process        |
| Process Control Block (PCB) | struct with PID, state, RAM, HDD, queue level, priority    |
| Shared Memory               | shm_open + mmap — resource table shared across all procs   |
| Multilevel Queue Scheduler  | 3 levels: Foreground, Background, System                   |
| Round Robin                 | Level 0 (foreground) — 500ms time slice                    |
| FCFS                        | Level 1 (background) — first come first served             |
| Priority Scheduling         | Level 2 (system) — lowest priority number runs first       |
| Mutex                       | pthread_mutex_t protects queues and resource counters      |
| Semaphore                   | sem_t sem_cores — tracks available CPU cores               |
| Condition Variable          | pthread_cond_t — scheduler sleeps when all queues empty    |
| Context Switching           | SIGSTOP to pause, SIGCONT to resume processes              |
| User Mode / Kernel Mode     | Password-gated kernel console with full process control    |
| Interrupt Simulation        | Close = SIGTERM, Minimize = SIGSTOP, Restore = SIGCONT     |
| Resource Management         | RAM and HDD tracked; process denied if insufficient        |
| Multitasking                | Multiple processes run simultaneously up to core limit     |
| Threads                     | Notepad autosave, scheduler, timer all use pthreads        |
| EXEC Commands               | execlp() used to launch every task binary                  |
| Boot Sequence               | Animated splash with OS name and loading steps             |
| Pipe IPC                    | Child sends RAM/HDD needs to parent before starting        |
| Shutdown                    | Graceful: kills all child processes, releases shared mem   |

---

## Task Categories

### Foreground Tasks (need user input)
Tasks 1-10. These run interactively. The user types commands inside them.
Type 'exit' to close and return to the OS menu.

### Background Tasks (run on their own)
Tasks 11-15. These simulate jobs that run without user interaction
(music playback, printing, logging, backup, disk cleanup).
Press Ctrl+C or type 'exit' to stop them.

### System Tasks (OS utilities)
Tasks 16-20. These show system information like clock, calendar,
RAM usage, running processes, and hardware info.

---

## Common Issues

Problem: "Not enough resources to start task"
Fix: Type 'res' to check RAM usage. Close other tasks first.

Problem: Output is mixed between OS menu and task
Fix: This happens without xterm. Install it: sudo apt install xterm

Problem: "make: No rule to make target"
Fix: Make sure you are inside the OS_Simulator folder: cd OS_Simulator

Problem: "Permission denied" on task binaries
Fix: chmod +x tasks/*

Problem: Shared memory error on startup
Fix: Remove old shared memory: rm -f /dev/shm/OS_RESOURCES

---

## Notes

- Kernel mode password is: admin
- All files created by tasks are saved in the current directory
- Notepad auto-saves to: notepad_save.txt
- Log generator writes to: system.log
- Auto-backup creates files named: backup_TIMESTAMP_filename

---

## License

Academic project — FAST-NUCES CF Campus, Spring 2026
