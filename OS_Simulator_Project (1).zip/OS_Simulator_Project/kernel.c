// kernel.c
// ─────────────────────────────────────────────────────────────
//  Kernel Mode vs User Mode
//
//  User Mode  : can launch tasks, view status, minimise
//  Kernel Mode: additionally can kill ANY process, view full
//               memory map, and directly manipulate PCBs.
//
//  Mode switch: user types "kernel" + password.
//               Password is set at OS boot (default: "admin").
//
//  Process table lives here.  The scheduler and resource manager
//  share it via pointers.
// ─────────────────────────────────────────────────────────────

#include "kernel.h"
#include "resource_manager.h"
#include "scheduler.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_PROCS  64

static PCB   g_proc_table[MAX_PROCS];
static int   g_proc_count    = 0;
static int   g_next_id       = 1;        // internal OS PID counter
static int   g_kernel_mode   = 0;        // 0 = user, 1 = kernel
static char  g_kernel_pass[64] = "admin";

// ─────────────────────────────────────────────
//  kernel_init  — call once at OS startup
// ─────────────────────────────────────────────
void kernel_init(const char *password) {
    memset(g_proc_table, 0, sizeof(g_proc_table));
    g_proc_count  = 0;
    g_kernel_mode = 0;
    if (password) strncpy(g_kernel_pass, password, 63);
}

// ─────────────────────────────────────────────
//  Mode switching
// ─────────────────────────────────────────────
int kernel_enter(const char *password) {
    if (strcmp(password, g_kernel_pass) == 0) {
        g_kernel_mode = 1;
        printf("\n[KERNEL] Kernel mode ACTIVE. Handle with care.\n");
        return 1;
    }
    printf("[KERNEL] Wrong password.\n");
    return 0;
}

void kernel_exit(void) {
    g_kernel_mode = 0;
    printf("[KERNEL] Returned to User mode.\n");
}

int kernel_is_kernel_mode(void) { return g_kernel_mode; }

// ─────────────────────────────────────────────
//  process_create
//  Forks a new process and exec's the task binary.
//  A pipe is used so the child can tell the parent
//  how much RAM/HDD it needs BEFORE we grant it.
//
//  Flow:
//   Parent                         Child (task binary)
//   ──────                         ─────────────────────
//   fork()
//                                  write "RAM=50 HDD=10\n" to pipe
//   read pipe → check resources
//   if OK  → write "GRANT\n"       read "GRANT\n" → start working
//   if FAIL→ write "DENY\n"        read "DENY\n"  → exit(1)
//   add PCB to table
//   add PCB to scheduler queue
// ─────────────────────────────────────────────
PCB *process_create(const char *name, const char *binary_path,
                    int queue_level, int priority,
                    int ram_mb, int hdd_mb) {

    if (g_proc_count >= MAX_PROCS) {
        printf("[KERNEL] Process table full.\n");
        return NULL;
    }

    // Check resources before forking
    if (!resource_request(ram_mb, hdd_mb)) {
        printf("[KERNEL] Not enough resources to start '%s' "
               "(needs %dMB RAM, %dMB HDD).\n", name, ram_mb, hdd_mb);
        return NULL;
    }

    // ── create the pipe ──
    int pipefd[2];
    if (pipe(pipefd) < 0) { perror("pipe"); return NULL; }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork");
        resource_release(ram_mb, hdd_mb);
        return NULL;
    }

    if (pid == 0) {
        // ── CHILD ──────────────────────────────────────────
        // Close the read end; child only writes
        close(pipefd[0]);

        // Send our resource requirements to parent
        char msg[64];
        snprintf(msg, sizeof(msg), "RAM=%d HDD=%d\n", ram_mb, hdd_mb);
        write(pipefd[1], msg, strlen(msg));
        close(pipefd[1]);

        // Now exec the actual task binary.
        // We pass ram_mb and hdd_mb as argv so the task knows its budget.
        char ram_str[16], hdd_str[16];
        snprintf(ram_str, sizeof(ram_str), "%d", ram_mb);
        snprintf(hdd_str, sizeof(hdd_str), "%d", hdd_mb);
        execlp(binary_path, binary_path, ram_str, hdd_str, NULL);

        // If exec fails
        perror("exec");
        _exit(1);
    }

    // ── PARENT ─────────────────────────────────────────────
    close(pipefd[1]);   // close write end; parent only reads

    // Read child's resource announcement (we already checked, just consume)
    char buf[64];
    int  n = read(pipefd[0], buf, sizeof(buf) - 1);
    if (n > 0) buf[n] = '\0';
    close(pipefd[0]);

    // Fill in PCB
    PCB *p = &g_proc_table[g_proc_count++];
    memset(p, 0, sizeof(PCB));
    p->id          = g_next_id++;
    p->pid         = pid;
    strncpy(p->name, name, MAX_NAME_LEN - 1);
    p->state       = STATE_READY;
    p->ram_mb      = ram_mb;
    p->hdd_mb      = hdd_mb;
    p->queue_level = queue_level;
    p->priority    = priority;
    p->core_id     = -1;

    // Update shared resource table's process count
    ResourceTable *rt = resource_get_table();
    if (rt) rt->process_count = g_proc_count;

    // Hand off to scheduler
    scheduler_add(p);

    printf("[KERNEL] Created process '%s' PID=%d RAM=%dMB HDD=%dMB\n",
           name, pid, ram_mb, hdd_mb);
    return p;
}

// ─────────────────────────────────────────────
//  process_kill  (requires kernel mode for other users' processes)
// ─────────────────────────────────────────────
int process_kill(int internal_id) {
    for (int i = 0; i < g_proc_count; i++) {
        PCB *p = &g_proc_table[i];
        if (p->id == internal_id && p->state != STATE_TERMINATED) {
            kill(p->pid, SIGTERM);
            waitpid(p->pid, NULL, WNOHANG);
            resource_release(p->ram_mb, p->hdd_mb);
            scheduler_remove(p);
            p->state = STATE_TERMINATED;
            ResourceTable *rt = resource_get_table();
            if (rt) rt->process_count--;
            printf("[KERNEL] Killed process '%s' (ID=%d)\n", p->name, p->id);
            return 1;
        }
    }
    printf("[KERNEL] No process with ID %d.\n", internal_id);
    return 0;
}

// ─────────────────────────────────────────────
//  process_minimize / restore
// ─────────────────────────────────────────────
void process_minimize(int internal_id) {
    for (int i = 0; i < g_proc_count; i++) {
        PCB *p = &g_proc_table[i];
        if (p->id == internal_id && p->state != STATE_TERMINATED) {
            kill(p->pid, SIGSTOP);   // pause the process
            p->state = STATE_MINIMIZED;
            // RAM stays allocated — process is still "in memory"
            printf("[KERNEL] Minimized '%s' (RAM still allocated)\n", p->name);
            return;
        }
    }
}

void process_restore(int internal_id) {
    for (int i = 0; i < g_proc_count; i++) {
        PCB *p = &g_proc_table[i];
        if (p->id == internal_id && p->state == STATE_MINIMIZED) {
            kill(p->pid, SIGCONT);
            p->state = STATE_RUNNING;
            printf("[KERNEL] Restored '%s'\n", p->name);
            return;
        }
    }
}

// ─────────────────────────────────────────────
//  process_list  — print all processes
// ─────────────────────────────────────────────
void process_list(void) {
    const char *state_str[] = {"READY","RUNNING","BLOCKED","TERMINATED","MINIMIZED"};
    const char *level_str[] = {"FOREGROUND","BACKGROUND","SYSTEM"};
    printf("\n┌────┬──────┬──────────────────────┬───────────┬────────┬──────┬──────┐\n");
    printf("│ ID │ PID  │ Name                 │ State     │ Level  │ RAM  │ HDD  │\n");
    printf("├────┼──────┼──────────────────────┼───────────┼────────┼──────┼──────┤\n");
    for (int i = 0; i < g_proc_count; i++) {
        PCB *p = &g_proc_table[i];
        if (p->state == STATE_TERMINATED) continue;
        printf("│%3d │%5d │ %-20s │ %-9s │ %-6s │%4dM │%4dM │\n",
               p->id, p->pid, p->name,
               state_str[p->state],
               level_str[p->queue_level],
               p->ram_mb, p->hdd_mb);
    }
    printf("└────┴──────┴──────────────────────┴───────────┴────────┴──────┴──────┘\n");
}

// ─────────────────────────────────────────────
//  kernel_menu  — interactive kernel-mode shell
// ─────────────────────────────────────────────
void kernel_menu(void) {
    char cmd[128];
    printf("\n╔══════════════════════════════╗\n");
    printf("║     KERNEL MODE CONSOLE      ║\n");
    printf("╠══════════════════════════════╣\n");
    printf("║ list   - list all processes  ║\n");
    printf("║ kill N - kill process ID N   ║\n");
    printf("║ min  N - minimize ID N       ║\n");
    printf("║ res N  - restore  ID N       ║\n");
    printf("║ mem    - memory status       ║\n");
    printf("║ exit   - leave kernel mode   ║\n");
    printf("╚══════════════════════════════╝\n");

    while (1) {
        printf("kernel# ");
        fflush(stdout);
        if (!fgets(cmd, sizeof(cmd), stdin)) break;
        cmd[strcspn(cmd, "\n")] = 0;

        if (strcmp(cmd, "list") == 0) {
            process_list();
        } else if (strncmp(cmd, "kill ", 5) == 0) {
            int id = atoi(cmd + 5);
            process_kill(id);
        } else if (strncmp(cmd, "min ", 4) == 0) {
            int id = atoi(cmd + 4);
            process_minimize(id);
        } else if (strncmp(cmd, "res ", 4) == 0) {
            int id = atoi(cmd + 4);
            process_restore(id);
        } else if (strcmp(cmd, "mem") == 0) {
            resource_status();
        } else if (strcmp(cmd, "exit") == 0) {
            kernel_exit();
            break;
        } else {
            printf("Unknown command. Try: list, kill N, min N, res N, mem, exit\n");
        }
    }
}

// Accessors
PCB *kernel_get_proc_table(void) { return g_proc_table; }
int  kernel_get_proc_count(void) { return g_proc_count; }
