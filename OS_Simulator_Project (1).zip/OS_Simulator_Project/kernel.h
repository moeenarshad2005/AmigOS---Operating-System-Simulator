#ifndef KERNEL_H
#define KERNEL_H

#include "process.h"

void  kernel_init(const char *password);
int   kernel_enter(const char *password);
void  kernel_exit(void);
int   kernel_is_kernel_mode(void);
PCB  *process_create(const char *name, const char *binary_path,
                     int queue_level, int priority,
                     int ram_mb, int hdd_mb);
int   process_kill(int internal_id);
void  process_minimize(int internal_id);
void  process_restore(int internal_id);
void  process_list(void);
void  kernel_menu(void);
PCB  *kernel_get_proc_table(void);
int   kernel_get_proc_count(void);

#endif
