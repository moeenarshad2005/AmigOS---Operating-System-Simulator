// os.c  — AmiGos_OS Main Entry Point
// ─────────────────────────────────────────────────────────────
//  Usage: ./OS <RAM_MB> <HDD_MB> <CORES>
//  Example: ./OS 2048 256000 8
//
//  This is the "init" process of AmiGos_OS.
//  It:
//    1. Parses hardware resources from command-line args
//    2. Shows a boot splash screen (with loading animation)
//    3. Initialises shared memory, scheduler, kernel
//    4. Auto-starts system tasks (clock, calendar, log)
//    5. Presents an interactive shell for the user
//    6. Handles user mode / kernel mode switching
// ─────────────────────────────────────────────────────────────

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <pthread.h>

#include "process.h"
#include "resource_manager.h"
#include "scheduler.h"
#include "kernel.h"

// ── ANSI colour helpers ───────────────────────────────────────
#define CLR_RESET  "\033[0m"
#define CLR_CYAN   "\033[1;36m"
#define CLR_GREEN  "\033[1;32m"
#define CLR_YELLOW "\033[1;33m"
#define CLR_RED    "\033[1;31m"
#define CLR_BLUE   "\033[1;34m"
#define CLR_WHITE  "\033[1;37m"

// ── Task catalogue ────────────────────────────────────────────
//  Each entry: { display name, binary path, queue level, priority, RAM MB, HDD MB }
typedef struct {
    const char *name;
    const char *binary;
    int         queue;
    int         priority;
    int         ram_mb;
    int         hdd_mb;
    const char *description;
    const char *type;   // "fg" | "bg" | "sys"
} TaskDef;

static TaskDef TASKS[] = {
    // ── Foreground (user interactive) ──
    { "Calculator",      "./tasks/calculator",   QUEUE_FOREGROUND, 5, 32,  0,  "Basic math calculator",            "fg"  },
    { "Notepad",         "./tasks/notepad",       QUEUE_FOREGROUND, 5, 64,  10, "Text editor with auto-save",       "fg"  },
    { "File Manager",    "./tasks/file_manager",  QUEUE_FOREGROUND, 5, 32,  5,  "Create/copy/move/delete files",    "fg"  },
    { "Text Search",     "./tasks/text_search",   QUEUE_FOREGROUND, 5, 16,  0,  "Search text in files",             "fg"  },
    { "Random Number",   "./tasks/rng",           QUEUE_FOREGROUND, 5, 16,  0,  "Random number generator",          "fg"  },
    { "Word Count",      "./tasks/word_count",    QUEUE_FOREGROUND, 5, 16,  0,  "Count words/lines in files",       "fg"  },
    { "Encryptor",       "./tasks/encryptor",     QUEUE_FOREGROUND, 5, 16,  5,  "XOR file encrypt/decrypt",         "fg"  },
    { "Timer/Alarm",     "./tasks/timer",         QUEUE_FOREGROUND, 5, 16,  0,  "Countdown timer with labels",      "fg"  },
    { "Minesweeper",     "./tasks/minesweeper",   QUEUE_FOREGROUND, 3, 32,  0,  "Classic minesweeper game",         "fg"  },
    { "Snake Game",      "./tasks/snake",         QUEUE_FOREGROUND, 3, 32,  0,  "Snake game (WASD controls)",       "fg"  },

    // ── Background ──
    { "Music Player",    "./tasks/music",         QUEUE_BACKGROUND, 8, 64,  0,  "Background music simulation",      "bg"  },
    { "Print Job",       "./tasks/print_sim",     QUEUE_BACKGROUND, 8, 32,  5,  "Simulate printing a file",         "bg"  },
    { "Log Generator",   "./tasks/log_gen",       QUEUE_BACKGROUND, 8, 16,  10, "Background system logger",         "bg"  },
    { "Auto-Backup",     "./tasks/auto_backup",   QUEUE_BACKGROUND, 8, 16,  20, "Auto-backup files every 30s",      "bg"  },
    { "Disk Cleaner",    "./tasks/disk_cleaner",  QUEUE_BACKGROUND, 8, 16,  0,  "Remove temp and backup files",     "bg"  },

    // ── System ──
    { "Clock",           "./tasks/clock",         QUEUE_SYSTEM,     1, 16,  0,  "Real-time clock display",          "sys" },
    { "Calendar",        "./tasks/calendar",      QUEUE_SYSTEM,     2, 16,  0,  "Monthly calendar",                 "sys" },
    { "RAM Viewer",      "./tasks/ram_viewer",    QUEUE_SYSTEM,     2, 16,  0,  "Real-time RAM usage",              "sys" },
    { "Process Viewer",  "./tasks/proc_viewer",   QUEUE_SYSTEM,     2, 16,  0,  "List running processes",           "sys" },
    { "System Info",     "./tasks/sysinfo",       QUEUE_SYSTEM,     3, 16,  0,  "Hardware & OS information",        "sys" },
};
#define TASK_COUNT ((int)(sizeof(TASKS)/sizeof(TASKS[0])))

// ── SIGCHLD handler — reap zombie children automatically ──────
void sigchld_handler(int sig) {
    (void)sig;
    while (waitpid(-1, NULL, WNOHANG) > 0);
}

// ── SIGINT handler — graceful shutdown ────────────────────────
static volatile int g_shutdown = 0;
void sigint_handler(int sig) { (void)sig; g_shutdown = 1; }

// ─────────────────────────────────────────────
//  boot_screen  — the "loading" animation
// ─────────────────────────────────────────────
void boot_screen(int ram, int hdd, int cores) {
    printf("\033[2J\033[H");   // clear screen

    printf(CLR_CYAN);
    printf("   █████╗ ███╗   ███╗██╗ ██████╗  ██████╗ ███████╗\n");
    printf("  ██╔══██╗████╗ ████║██║██╔════╝ ██╔═══██╗██╔════╝\n");
    printf("  ███████║██╔████╔██║██║██║  ███╗██║   ██║███████╗\n");
    printf("  ██╔══██║██║╚██╔╝██║██║██║   ██║██║   ██║╚════██║\n");
    printf("  ██║  ██║██║ ╚═╝ ██║██║╚██████╔╝╚██████╔╝███████║\n");
    printf("  ╚═╝  ╚═╝╚═╝     ╚═╝╚═╝ ╚═════╝  ╚═════╝ ╚══════╝\n");
    printf(CLR_RESET);
    printf(CLR_YELLOW "               AmigOS v1.0\n" CLR_RESET);
    printf(CLR_WHITE  "         Developed for OS Lab Spring 2026\n\n" CLR_RESET);

    printf(CLR_GREEN "  Hardware Configuration:\n" CLR_RESET);
    printf("    RAM    : %d MB\n", ram);
    printf("    HDD    : %d MB\n", hdd);
    printf("    Cores  : %d\n\n", cores);

    const char *steps[] = {
        "Initialising memory management...",
        "Starting process scheduler...",
        "Loading kernel modules...",
        "Setting up resource table...",
        "Launching system services...",
        "AmiGos_OS ready.",
    };
    for (int i = 0; i < 6; i++) {
        printf("  " CLR_GREEN "[ OK ]" CLR_RESET " %s\n", steps[i]);
        fflush(stdout);
        usleep(400000);   // 0.4 second per step
    }
    sleep(5);
    printf("\033[2J\033[H");
}

// ─────────────────────────────────────────────
//  print_menu  — show task list
// ─────────────────────────────────────────────
void print_menu(void) {
    printf(CLR_CYAN "\n╔══════════════════════════════════════════════════════════════╗\n");
    printf(         "║                    AmiGos_OS Task Menu                          ║\n");
    printf(         "╠══════════════════════════════════════════════════════════════╣\n" CLR_RESET);

    const char *type_labels[] = { "FOREGROUND", "BACKGROUND", "SYSTEM    " };
    const char *colours[]     = { CLR_WHITE,    CLR_YELLOW,   CLR_GREEN   };
    int current_type = -1;

    for (int i = 0; i < TASK_COUNT; i++) {
        int t = (strcmp(TASKS[i].type,"fg")==0)  ? 0 :
                (strcmp(TASKS[i].type,"bg")==0)  ? 1 : 2;
        if (t != current_type) {
            current_type = t;
            printf(CLR_CYAN "╠── %s ─────────────────────────────────────────────╣\n" CLR_RESET,
                   type_labels[t]);
        }
        printf("%s  %2d. %-18s" CLR_RESET "  %s\n",
               colours[t], i+1, TASKS[i].name, TASKS[i].description);
    }

    printf(CLR_CYAN "╠══════════════════════════════════════════════════════════════╣\n" CLR_RESET);
    printf("   ps   - list running processes\n");
    printf("   res  - resource status\n");
    printf("   q    - show scheduler queue\n");
    printf("   kernel - enter kernel mode\n");
    printf("   shutdown - shut down AmiGos_OS\n");
    printf(CLR_CYAN "╚══════════════════════════════════════════════════════════════╝\n\n" CLR_RESET);
}

// ─────────────────────────────────────────────
//  launch_task  — fork + exec in a new xterm
// ─────────────────────────────────────────────
void launch_task(int task_index) {
    TaskDef *t = &TASKS[task_index];
    printf(CLR_GREEN "\n[OS] Launching '%s'...\n" CLR_RESET, t->name);
    printf("[OS] Type 'exit' inside the task to return to OS menu.\n\n");

    char ram_str[16], hdd_str[16];
    snprintf(ram_str, sizeof(ram_str), "%d", t->ram_mb);
    snprintf(hdd_str, sizeof(hdd_str), "%d", t->hdd_mb);

    // Check resources first
    if (!resource_request(t->ram_mb, t->hdd_mb)) {
        printf(CLR_RED "[OS] Not enough resources for '%s'.\n" CLR_RESET, t->name);
        return;
    }

    // Add to process table for tracking
    PCB *p = &(kernel_get_proc_table()[kernel_get_proc_count()]);
    memset(p, 0, sizeof(PCB));
    p->pid       = getpid();
    p->state     = STATE_RUNNING;
    p->ram_mb    = t->ram_mb;
    p->hdd_mb    = t->hdd_mb;
    strncpy(p->name, t->name, MAX_NAME_LEN - 1);

    // Run task directly in this terminal (blocking until user exits)
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "%s %s %s", t->binary, ram_str, hdd_str);
    system(cmd);

    // Task finished — release resources
    resource_release(t->ram_mb, t->hdd_mb);
    printf(CLR_GREEN "\n[OS] '%s' closed. Returning to menu...\n" CLR_RESET, t->name);
}

// ─────────────────────────────────────────────
//  auto_start  — system tasks that run at boot
// ─────────────────────────────────────────────
void auto_start(void) {
    printf(CLR_GREEN "[OS] System ready.\n\n" CLR_RESET);
}

// ─────────────────────────────────────────────
//  shutdown  — graceful OS shutdown
// ─────────────────────────────────────────────
void do_shutdown(void) {
    printf("\033[2J\033[H");
    printf(CLR_CYAN "\n  Shutting down AmiGos_OS...\n" CLR_RESET);

    // Kill all child processes
    PCB   *procs = kernel_get_proc_table();
    int    count = kernel_get_proc_count();
    for (int i = 0; i < count; i++) {
        if (procs[i].state != STATE_TERMINATED && procs[i].pid > 0) {
            kill(procs[i].pid, SIGTERM);
        }
    }
    sleep(1);

    scheduler_shutdown();
    resource_cleanup();

    printf(CLR_YELLOW "\n  Thank you for using AmiGos_OS.\n");
    printf("  Goodbye!\n\n" CLR_RESET);
    exit(0);
}

// ─────────────────────────────────────────────
//  main
// ─────────────────────────────────────────────
int main(int argc, char *argv[]) {
    // ── 1. Parse hardware args ──────────────────
    if (argc < 4) {
        fprintf(stderr,
            "Usage: ./OS <RAM_MB> <HDD_MB> <CORES>\n"
            "Example: ./OS 2048 256000 8\n");
        return 1;
    }
    int ram_mb  = atoi(argv[1]);
    int hdd_mb  = atoi(argv[2]);
    int cores   = atoi(argv[3]);

    if (ram_mb <= 0 || hdd_mb <= 0 || cores <= 0) {
        fprintf(stderr, "All values must be positive integers.\n");
        return 1;
    }

    // ── 2. Signal setup ─────────────────────────
    signal(SIGCHLD, sigchld_handler);
    signal(SIGINT,  sigint_handler);

    // ── 3. Boot sequence ────────────────────────
    boot_screen(ram_mb, hdd_mb, cores);

    // ── 4. Init subsystems ──────────────────────
    resource_init(ram_mb, hdd_mb, cores);
    kernel_init("admin");
    scheduler_init(cores);

    // ── 5. Auto-start system tasks ──────────────
    auto_start();

    // ── 6. Main interactive shell ───────────────
    char input[128];
    while (!g_shutdown) {
        print_menu();
        printf(CLR_WHITE "AmiGos_OS> " CLR_RESET);
        fflush(stdout);

        if (!fgets(input, sizeof(input), stdin)) break;
        input[strcspn(input, "\n")] = 0;

        if (strlen(input) == 0) continue;

        // ── Numeric: launch task ──────────────
        char *endptr;
        long  choice = strtol(input, &endptr, 10);
        if (*endptr == '\0' && choice >= 1 && choice <= TASK_COUNT) {
            launch_task((int)choice - 1);
            continue;
        }

        // ── String commands ───────────────────
        if (strcmp(input, "ps") == 0) {
            process_list();

        } else if (strcmp(input, "res") == 0) {
            resource_status();

        } else if (strcmp(input, "q") == 0) {
            scheduler_print_queues();

        } else if (strcmp(input, "kernel") == 0) {
            printf("Kernel password: ");
            fflush(stdout);
            char pass[64];
            if (fgets(pass, sizeof(pass), stdin)) {
                pass[strcspn(pass, "\n")] = 0;
                if (kernel_enter(pass)) kernel_menu();
            }

        } else if (strcmp(input, "shutdown") == 0) {
            printf("Confirm shutdown? (yes/no): ");
            fflush(stdout);
            char ans[8];
            if (fgets(ans, sizeof(ans), stdin) && strncmp(ans,"yes",3)==0)
                do_shutdown();
            else
                printf("[OS] Shutdown cancelled.\n");

        } else if (strcmp(input, "help") == 0) {
            print_menu();

        } else {
            printf(CLR_RED "[OS] Unknown command: '%s'. Type a number (1-%d) or a command.\n" CLR_RESET,
                   input, TASK_COUNT);
        }
    }

    do_shutdown();
    return 0;
}
