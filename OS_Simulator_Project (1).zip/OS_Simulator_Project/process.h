#ifndef PROCESS_H
#define PROCESS_H

#include <sys/types.h>

// ─────────────────────────────────────────────
//  Process States
//  Every process lives in exactly one of these
// ─────────────────────────────────────────────
#define STATE_READY       0   // waiting in queue to run
#define STATE_RUNNING     1   // currently on a CPU core
#define STATE_BLOCKED     2   // waiting for I/O or input
#define STATE_TERMINATED  3   // finished / killed
#define STATE_MINIMIZED   4   // paused, stays in RAM

// ─────────────────────────────────────────────
//  Queue Levels  (Multilevel Queue Scheduler)
//  Level 0 = Foreground  → Round Robin
//  Level 1 = Background  → FCFS
//  Level 2 = System      → Priority (lowest number = highest priority)
// ─────────────────────────────────────────────
#define QUEUE_FOREGROUND  0
#define QUEUE_BACKGROUND  1
#define QUEUE_SYSTEM      2

#define MAX_PROCESSES     64
#define MAX_NAME_LEN      64

// ─────────────────────────────────────────────
//  Process Control Block  (PCB)
//  One struct per process — the OS's "file" on
//  every running program.
// ─────────────────────────────────────────────
typedef struct {
    int    pid;                    // actual Linux PID (from fork)
    int    id;                     // internal OS process ID
    char   name[MAX_NAME_LEN];     // human-readable name
    int    state;                  // one of STATE_* above
    int    ram_mb;                 // RAM needed in MB
    int    hdd_mb;                 // Hard disk needed in MB
    int    queue_level;            // which scheduler queue
    int    priority;               // lower = higher priority (used in system queue)
    int    time_slice_ms;          // how long it runs before being preempted
    int    remaining_time_ms;      // time left in current slice
    int    pipe_fd[2];             // pipe: child writes needs, parent reads
    int    core_id;                // which CPU core it is assigned to (-1 = none)
} PCB;

// ─────────────────────────────────────────────
//  Shared resource table (in shared memory)
// ─────────────────────────────────────────────
typedef struct {
    int total_ram_mb;
    int used_ram_mb;
    int total_hdd_mb;
    int used_hdd_mb;
    int total_cores;
    int used_cores;
    int process_count;
    PCB processes[MAX_PROCESSES];
} ResourceTable;

#endif // PROCESS_H
