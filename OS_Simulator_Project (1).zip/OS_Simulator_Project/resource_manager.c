// resource_manager.c
// ─────────────────────────────────────────────────────────────
//  Manages RAM, Hard Disk, and CPU cores.
//  Uses POSIX shared memory so every child process can read
//  the same resource table without any network calls.
//
//  How shared memory works here:
//    1. Parent calls resource_init() → creates /OS_RESOURCES shm object
//    2. Every child calls resource_attach() → maps the same memory
//    3. All reads/writes go through a mutex so no two processes
//       corrupt the table simultaneously
// ─────────────────────────────────────────────────────────────

#include "resource_manager.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>

#define SHM_NAME "/OS_RESOURCES"

// ── module-level pointer to shared memory ──
static ResourceTable *g_res = NULL;

// ── mutex protecting the resource table ──
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;

// ─────────────────────────────────────────────
//  resource_init
//  Called ONCE by the parent OS process.
//  total_ram / total_hdd in MB, cores = number of CPU cores.
// ─────────────────────────────────────────────
int resource_init(int total_ram, int total_hdd, int cores) {
    // shm_open creates a named shared memory region (like a file in RAM)
    int fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (fd < 0) { perror("shm_open"); return -1; }

    // size the region to hold one ResourceTable
    if (ftruncate(fd, sizeof(ResourceTable)) < 0) { perror("ftruncate"); return -1; }

    // mmap maps it into THIS process's address space
    g_res = mmap(NULL, sizeof(ResourceTable),
                 PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (g_res == MAP_FAILED) { perror("mmap"); return -1; }

    memset(g_res, 0, sizeof(ResourceTable));
    g_res->total_ram_mb  = total_ram;
    g_res->total_hdd_mb  = total_hdd;
    g_res->total_cores   = cores;
    g_res->used_ram_mb   = 0;
    g_res->used_hdd_mb   = 0;
    g_res->used_cores    = 0;
    g_res->process_count = 0;
    return 0;
}

// ─────────────────────────────────────────────
//  resource_attach
//  Called by child processes to connect to
//  the same shared memory the parent created.
// ─────────────────────────────────────────────
int resource_attach(void) {
    int fd = shm_open(SHM_NAME, O_RDWR, 0666);
    if (fd < 0) { perror("shm_open attach"); return -1; }
    g_res = mmap(NULL, sizeof(ResourceTable),
                 PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    close(fd);
    if (g_res == MAP_FAILED) { perror("mmap attach"); return -1; }
    return 0;
}

// ─────────────────────────────────────────────
//  resource_request
//  A process asks for ram_mb of RAM, hdd_mb of disk,
//  and 1 CPU core.  Returns 1 if granted, 0 if denied.
// ─────────────────────────────────────────────
int resource_request(int ram_mb, int hdd_mb) {
    pthread_mutex_lock(&g_lock);
    int ok = (g_res->used_ram_mb + ram_mb <= g_res->total_ram_mb) &&
             (g_res->used_hdd_mb + hdd_mb <= g_res->total_hdd_mb);
    if (ok) {
        g_res->used_ram_mb += ram_mb;
        g_res->used_hdd_mb += hdd_mb;
    }
    pthread_mutex_unlock(&g_lock);
    return ok;
}

// ─────────────────────────────────────────────
//  resource_release
//  Called when a process finishes or is killed.
//  Returns the resources it was using back to the pool.
// ─────────────────────────────────────────────
void resource_release(int ram_mb, int hdd_mb) {
    pthread_mutex_lock(&g_lock);
    g_res->used_ram_mb -= ram_mb;
    g_res->used_hdd_mb -= hdd_mb;
    pthread_mutex_unlock(&g_lock);
}

// ─────────────────────────────────────────────
//  resource_status  — prints a summary bar
// ─────────────────────────────────────────────
void resource_status(void) {
    if (!g_res) { printf("Resource table not initialised.\n"); return; }
    printf("\n┌─────────────────────────────────────┐\n");
    printf("│         RESOURCE STATUS             │\n");
    printf("├─────────────────────────────────────┤\n");
    printf("│ RAM  : %4d / %4d MB used           │\n",
           g_res->used_ram_mb,  g_res->total_ram_mb);
    printf("│ HDD  : %4d / %4d MB used           │\n",
           g_res->used_hdd_mb,  g_res->total_hdd_mb);
    printf("│ CORES: %4d / %4d  used             │\n",
           g_res->used_cores,   g_res->total_cores);
    printf("│ PROCS: %4d running                 │\n",
           g_res->process_count);
    printf("└─────────────────────────────────────┘\n");
}

// ─────────────────────────────────────────────
//  Getters used by scheduler and kernel
// ─────────────────────────────────────────────
ResourceTable *resource_get_table(void) { return g_res; }

int resource_free_ram(void)  { return g_res ? g_res->total_ram_mb - g_res->used_ram_mb  : 0; }
int resource_free_hdd(void)  { return g_res ? g_res->total_hdd_mb - g_res->used_hdd_mb  : 0; }
int resource_free_cores(void){ return g_res ? g_res->total_cores  - g_res->used_cores   : 0; }

// ─────────────────────────────────────────────
//  resource_cleanup  — called on OS shutdown
// ─────────────────────────────────────────────
void resource_cleanup(void) {
    if (g_res) munmap(g_res, sizeof(ResourceTable));
    shm_unlink(SHM_NAME);
}
