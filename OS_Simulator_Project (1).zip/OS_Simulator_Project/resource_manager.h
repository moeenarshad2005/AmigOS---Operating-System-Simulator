#ifndef RESOURCE_MANAGER_H
#define RESOURCE_MANAGER_H

#include "process.h"

int            resource_init(int total_ram, int total_hdd, int cores);
int            resource_attach(void);
int            resource_request(int ram_mb, int hdd_mb);
void           resource_release(int ram_mb, int hdd_mb);
void           resource_status(void);
ResourceTable *resource_get_table(void);
int            resource_free_ram(void);
int            resource_free_hdd(void);
int            resource_free_cores(void);
void           resource_cleanup(void);

#endif
