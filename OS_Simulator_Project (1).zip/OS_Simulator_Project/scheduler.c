// scheduler.c
// ─────────────────────────────────────────────────────────────
//  Implements a Multilevel Queue Scheduler with three levels:
//
//   Level 0  FOREGROUND  → Round Robin   (time_slice = 200 ms)
//   Level 1  BACKGROUND  → FCFS          (runs to completion)
//   Level 2  SYSTEM      → Priority      (lower priority # first)
//
//  How it works:
//   • Each level has its own circular array (ring buffer) of PCB pointers.
//   • The scheduler thread wakes every TICK_MS milliseconds.
//   • It always drains Level 0 first, then 1, then 2 — higher levels
//     can starve lower ones, which is intentional (foreground > background).
//   • Synchronization:
//       - queue_mutex  : protects all three queues
//       - queue_cond   : scheduler thread sleeps here when all queues empty
//       - sem_cores    : counting semaphore = number of free cores
//         (each running process decrements it; releasing increments it)
// ─────────────────────────────────────────────────────────────

#include "scheduler.h"
#include "resource_manager.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <time.h>

#define QUEUE_CAPACITY  64
#define TICK_MS         200      // scheduler wakes every 200 ms
#define RR_SLICE_MS     500      // Round Robin time slice

// ── per-level queues ──────────────────────────────────────────
typedef struct {
    PCB  *slots[QUEUE_CAPACITY];
    int   head, tail, size;
} Queue;

static Queue g_queues[3];   // index = queue level

// ── synchronisation primitives ────────────────────────────────
static pthread_mutex_t queue_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  queue_cond  = PTHREAD_COND_INITIALIZER;
static sem_t           sem_cores;

static pthread_t scheduler_thread;
static int       scheduler_running = 0;

// ─────────────────────────────────────────────
//  Internal queue helpers  (call with lock held)
// ─────────────────────────────────────────────
static void q_push(Queue *q, PCB *p) {
    if (q->size >= QUEUE_CAPACITY) return;   // drop if full (should not happen)
    q->slots[q->tail] = p;
    q->tail = (q->tail + 1) % QUEUE_CAPACITY;
    q->size++;
}

static PCB *q_pop(Queue *q) {
    if (q->size == 0) return NULL;
    PCB *p = q->slots[q->head];
    q->head = (q->head + 1) % QUEUE_CAPACITY;
    q->size--;
    return p;
}

// Priority pop for Level 2: returns lowest priority number first
static PCB *q_pop_priority(Queue *q) {
    if (q->size == 0) return NULL;
    int best = -1;
    int bi   = q->head;
    for (int i = 0; i < q->size; i++) {
        int idx = (q->head + i) % QUEUE_CAPACITY;
        if (best == -1 || q->slots[idx]->priority < q->slots[bi]->priority) {
            best = q->slots[idx]->priority;
            bi   = idx;
        }
    }
    PCB *p = q->slots[bi];
    // compact: shift everything after bi one step back
    for (int i = 0; i < q->size - 1; i++) {
        int cur  = (bi + i)     % QUEUE_CAPACITY;
        int next = (bi + i + 1) % QUEUE_CAPACITY;
        q->slots[cur] = q->slots[next];
    }
    q->tail = (q->tail - 1 + QUEUE_CAPACITY) % QUEUE_CAPACITY;
    q->size--;
    return p;
}

// ─────────────────────────────────────────────
//  dispatch  — "run" one PCB
//  For a real OS this would context-switch;
//  here we SIGCONT a stopped process (or just
//  mark it RUNNING and let the process run).
// ─────────────────────────────────────────────
static void dispatch(PCB *p, int slice_ms) {
    (void)slice_ms;
    p->state             = STATE_RUNNING;
    p->remaining_time_ms = slice_ms;
}

// ─────────────────────────────────────────────
//  preempt  — pause a running process (Round Robin)
// ─────────────────────────────────────────────
static void preempt(PCB *p) {
    p->state = STATE_READY;
}

// ─────────────────────────────────────────────
//  scheduler_tick — the heart of the scheduler
//  Called every TICK_MS by the scheduler thread.
// ─────────────────────────────────────────────
static void scheduler_tick(void) {
    pthread_mutex_lock(&queue_mutex);

    // --- Level 0: Round Robin ---
    if (g_queues[QUEUE_FOREGROUND].size > 0) {
        // try to acquire a core (non-blocking)
        if (sem_trywait(&sem_cores) == 0) {
            PCB *p = q_pop(&g_queues[QUEUE_FOREGROUND]);
            pthread_mutex_unlock(&queue_mutex);
            dispatch(p, RR_SLICE_MS);
            // sleep for one slice
            usleep(RR_SLICE_MS * 1000);
            // after slice: if still running → preempt and re-enqueue
            if (p->state == STATE_RUNNING) {
                preempt(p);
                pthread_mutex_lock(&queue_mutex);
                q_push(&g_queues[QUEUE_FOREGROUND], p);
                pthread_mutex_unlock(&queue_mutex);
            }
            sem_post(&sem_cores);   // return the core
            return;
        }
    }

    // --- Level 1: FCFS background ---
    if (g_queues[QUEUE_BACKGROUND].size > 0) {
        if (sem_trywait(&sem_cores) == 0) {
            PCB *p = q_pop(&g_queues[QUEUE_BACKGROUND]);
            pthread_mutex_unlock(&queue_mutex);
            dispatch(p, 0);          // FCFS: no forced preemption
            sem_post(&sem_cores);
            return;
        }
    }

    // --- Level 2: Priority system tasks ---
    if (g_queues[QUEUE_SYSTEM].size > 0) {
        if (sem_trywait(&sem_cores) == 0) {
            PCB *p = q_pop_priority(&g_queues[QUEUE_SYSTEM]);
            pthread_mutex_unlock(&queue_mutex);
            dispatch(p, 0);
            sem_post(&sem_cores);
            return;
        }
    }

    pthread_mutex_unlock(&queue_mutex);
}

// ─────────────────────────────────────────────
//  Scheduler thread body
// ─────────────────────────────────────────────
static void *scheduler_loop(void *arg) {
    (void)arg;
    while (scheduler_running) {
        scheduler_tick();
        usleep(TICK_MS * 1000);
    }
    return NULL;
}

// ─────────────────────────────────────────────
//  Public API
// ─────────────────────────────────────────────

void scheduler_init(int num_cores) {
    memset(g_queues, 0, sizeof(g_queues));
    sem_init(&sem_cores, 0, num_cores);   // semaphore starts = total cores
    scheduler_running = 1;
    pthread_create(&scheduler_thread, NULL, scheduler_loop, NULL);
    printf("[SCHED] Scheduler started — %d cores, 3-level MLQ\n", num_cores);
}

void scheduler_add(PCB *p) {
    pthread_mutex_lock(&queue_mutex);
    p->state = STATE_READY;
    q_push(&g_queues[p->queue_level], p);
    pthread_cond_signal(&queue_cond);   // wake scheduler if sleeping
    //printf("[SCHED] Added PID %d (%s) → Level %d queue\n",
           //p->pid, p->name, p->queue_level);
    pthread_mutex_unlock(&queue_mutex);
}

void scheduler_block(PCB *p) {
    // Called when process is waiting for I/O
    p->state = STATE_BLOCKED;
    if (p->pid > 0) kill(p->pid, SIGSTOP);
    sem_post(&sem_cores);   // free the core while blocked
    printf("[SCHED] Blocked PID %d (%s)\n", p->pid, p->name);
}

void scheduler_unblock(PCB *p) {
    // Called when I/O completes — re-enqueue
    scheduler_add(p);
    printf("[SCHED] Unblocked PID %d (%s)\n", p->pid, p->name);
}

void scheduler_remove(PCB *p) {
    // Process terminated — just mark state; resource release handled elsewhere
    p->state = STATE_TERMINATED;
    printf("[SCHED] Removed PID %d (%s) from scheduler\n", p->pid, p->name);
}

void scheduler_shutdown(void) {
    scheduler_running = 0;
    pthread_join(scheduler_thread, NULL);
    sem_destroy(&sem_cores);
    printf("[SCHED] Scheduler stopped.\n");
}

void scheduler_print_queues(void) {
    pthread_mutex_lock(&queue_mutex);
    const char *names[] = {"FOREGROUND(RR)", "BACKGROUND(FCFS)", "SYSTEM(Priority)"};
    printf("\n[SCHED] Ready Queue Snapshot:\n");
    for (int l = 0; l < 3; l++) {
        printf("  Level %d %-20s: %d process(es)\n",
               l, names[l], g_queues[l].size);
        for (int i = 0; i < g_queues[l].size; i++) {
            int idx = (g_queues[l].head + i) % QUEUE_CAPACITY;
            PCB *p  = g_queues[l].slots[idx];
            if (p) printf("    → PID %d  %-20s  prio=%d\n",
                          p->pid, p->name, p->priority);
        }
    }
    pthread_mutex_unlock(&queue_mutex);
}
