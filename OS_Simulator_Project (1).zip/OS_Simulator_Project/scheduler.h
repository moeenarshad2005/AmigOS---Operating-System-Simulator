#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "process.h"

void scheduler_init(int num_cores);
void scheduler_add(PCB *p);
void scheduler_block(PCB *p);
void scheduler_unblock(PCB *p);
void scheduler_remove(PCB *p);
void scheduler_shutdown(void);
void scheduler_print_queues(void);

#endif
