// tasks/auto_backup.c
// Background task — backs up notepad_save.txt every 30 seconds
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <signal.h>

static volatile int g_running = 1;
void handle_sig(int s) { (void)s; g_running = 0; }

void backup_file(const char *src) {
    char dst[256];
    time_t now = time(NULL);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y%m%d_%H%M%S", localtime(&now));
    snprintf(dst, sizeof(dst), "backup_%s_%s", ts, src);

    FILE *in  = fopen(src, "r");
    if (!in) { printf("[Backup] Source not found: %s\n", src); return; }
    FILE *out = fopen(dst, "w");
    if (!out) { perror("backup write"); fclose(in); return; }

    char buf[4096]; size_t n;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0)
        fwrite(buf, 1, n, out);
    fclose(in); fclose(out);
    printf("[Backup] %s → %s\n", src, dst);
}

int main(void) {
    signal(SIGTERM, handle_sig);
    signal(SIGINT,  handle_sig);

    printf("╔════════════════════════════════════╗\n");
    printf("║           AUTO-BACKUP              ║\n");
    printf("║  Backs up notepad_save.txt every   ║\n");
    printf("║  30 seconds. Runs in background.   ║\n");
    printf("╚════════════════════════════════════╝\n");

    int count = 0;
    while (g_running) {
        sleep(30);
        if (!g_running) break;
        backup_file("notepad_save.txt");
        count++;
        printf("[Backup] Backup #%d complete.\n", count);
        fflush(stdout);
    }
    printf("[AutoBackup] Stopped after %d backups.\n", count);
    return 0;
}
