// tasks/calculator.c
// Full-time foreground task — requires user input the whole time.
// Supports +, -, *, /, % and remembers last result.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    printf("\n╔══════════════════════════════╗\n");
    printf("║        CALCULATOR            ║\n");
    printf("║  Type: 10 + 5  or  exit      ║\n");
    printf("╚══════════════════════════════╝\n");

    char line[256];
    double a, b, result = 0;
    char op;

    while (1) {
        printf("calc> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;
        if (strcmp(line, "exit") == 0) break;

        if (sscanf(line, "%lf %c %lf", &a, &op, &b) == 3) {
            switch (op) {
                case '+': result = a + b; break;
                case '-': result = a - b; break;
                case '*': result = a * b; break;
                case '/':
                    if (b == 0) { printf("Error: division by zero\n"); continue; }
                    result = a / b; break;
                case '%':
                    if ((long)b == 0) { printf("Error: modulo by zero\n"); continue; }
                    result = (long)a % (long)b; break;
                default:
                    printf("Unknown operator: %c\n", op); continue;
            }
            printf("= %.6g\n", result);
        } else {
            printf("Format: <number> <op> <number>  e.g.  10 + 5\n");
        }
    }
    printf("[Calculator] Closed.\n");
    return 0;
}
