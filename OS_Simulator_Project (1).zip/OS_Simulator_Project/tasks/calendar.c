// tasks/calendar.c
// System task — shows a monthly calendar. Auto-highlights today.
#include <stdio.h>
#include <time.h>
#include <string.h>

static const char *month_names[] = {
    "January","February","March","April","May","June",
    "July","August","September","October","November","December"
};
static const char *day_names = "Sun Mon Tue Wed Thu Fri Sat";

void print_month(int year, int month, int today_day) {
    // Find day of week for 1st of this month
    struct tm t = {0};
    t.tm_year = year - 1900;
    t.tm_mon  = month - 1;
    t.tm_mday = 1;
    mktime(&t);
    int start_wday = t.tm_wday;   // 0=Sun

    // Days in month
    int days_in_month[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (month == 2 && ((year%4==0 && year%100!=0) || year%400==0))
        days_in_month[1] = 29;

    printf("\n     %s %d\n", month_names[month-1], year);
    printf(" %s\n", day_names);
    printf(" ");
    for (int i = 0; i < start_wday; i++) printf("    ");

    for (int d = 1; d <= days_in_month[month-1]; d++) {
        if (d == today_day)
            printf("[%2d]", d);   // highlight today
        else
            printf(" %2d ", d);

        if ((start_wday + d) % 7 == 0) printf("\n ");
    }
    printf("\n");
}

int main(void) {
    time_t    now = time(NULL);
    struct tm *t  = localtime(&now);
    int year  = t->tm_year + 1900;
    int month = t->tm_mon  + 1;
    int day   = t->tm_mday;

    printf("╔════════════════════════════╗\n");
    printf("║         CALENDAR           ║\n");
    printf("╚════════════════════════════╝\n");

    char cmd[32];
    int  y = year, m = month;
    while (1) {
        print_month(y, m, (y == year && m == month) ? day : -1);
        printf("\nCommands: n=next month  p=prev month  t=today  exit\n> ");
        fflush(stdout);
        if (!fgets(cmd, sizeof(cmd), stdin)) break;
        cmd[strcspn(cmd, "\n")] = 0;
        if (strcmp(cmd, "exit") == 0) break;
        else if (strcmp(cmd, "n") == 0) { if (++m > 12) { m=1; y++; } }
        else if (strcmp(cmd, "p") == 0) { if (--m < 1)  { m=12; y--; } }
        else if (strcmp(cmd, "t") == 0) { y = year; m = month; }
    }
    printf("[Calendar] Closed.\n");
    return 0;
}
