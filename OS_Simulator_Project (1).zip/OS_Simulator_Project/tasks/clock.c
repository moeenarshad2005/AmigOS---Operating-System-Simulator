// tasks/clock.c
// System task — runs automatically, updates every second.
// Displays current time and date continuously.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <termios.h>
#include <fcntl.h>

static volatile int g_running = 1;
void handle_sigterm(int s) { (void)s; g_running = 0; }

// Check if a key has been pressed without blocking
int kbhit(void) {
    struct termios oldt, newt;
    int ch, oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if (ch != EOF) {
        ungetc(ch, stdin);
        return 1;
    }
    return 0;
}

int main(void) {
    signal(SIGTERM, handle_sigterm);
    signal(SIGINT,  handle_sigterm);

    printf("╔═══════════════════════════╗\n");
    printf("║        SYSTEM CLOCK       ║\n");
    printf("║   Press 'q' to exit       ║\n");
    printf("╚═══════════════════════════╝\n");

    int ticks = 0;
    const int MAX_TICKS = 60;

    while (g_running && ticks < MAX_TICKS) {
        // Check for 'q' keypress
        if (kbhit()) {
            int c = getchar();
            if (c == 'q' || c == 'Q') {
                g_running = 0;
                break;
            }
        }

        time_t     now = time(NULL);
        struct tm *t   = localtime(&now);

        char date_str[64], time_str[64];
        strftime(date_str, sizeof(date_str), "%A, %B %d %Y", t);
        strftime(time_str, sizeof(time_str), "%H:%M:%S",     t);

        printf("\r  Date: %-30s\n  Time: %-30s\n  [q to quit | %d/%d sec]       ",
               date_str, time_str, ticks + 1, MAX_TICKS);
        fflush(stdout);

        // Sleep in 100ms intervals so SIGTERM and 'q' are handled promptly
        for (int i = 0; i < 10 && g_running; i++) {
            usleep(100000);   // 100 ms
            if (kbhit()) {
                int c = getchar();
                if (c == 'q' || c == 'Q') {
                    g_running = 0;
                    break;
                }
            }
        }

        if (!g_running) break;

        ticks++;
        printf("\033[3A");
    }
    printf("\n\n[Clock] Stopped.\n");
    return 0;
}
