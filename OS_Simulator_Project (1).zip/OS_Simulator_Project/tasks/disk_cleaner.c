// tasks/disk_cleaner.c  — removes backup/temp files, shows freed space
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

long clean_files(const char *dir, const char *suffix) {
    DIR *d = opendir(dir ? dir : ".");
    if (!d) { perror("opendir"); return 0; }
    struct dirent *ent;
    long freed = 0;
    int  count = 0;
    while ((ent = readdir(d))) {
        size_t nlen = strlen(ent->d_name);
        size_t slen = strlen(suffix);
        if (nlen >= slen &&
            strcmp(ent->d_name + nlen - slen, suffix) == 0) {
            struct stat st;
            if (stat(ent->d_name, &st) == 0) {
                freed += st.st_size;
                remove(ent->d_name);
                printf("  Deleted: %-40s (%ld bytes)\n",
                       ent->d_name, (long)st.st_size);
                count++;
            }
        }
    }
    closedir(d);
    printf("  Removed %d file(s), freed %ld bytes\n", count, freed);
    return freed;
}

int main(void) {
    printf("╔═══════════════════════════════════════╗\n");
    printf("║           DISK CLEANER                ║\n");
    printf("╚═══════════════════════════════════════╝\n\n");
    printf("This will remove backup_ files and .tmp files\n");
    printf("from the current directory.\n");
    printf("Proceed? (yes/no): ");
    fflush(stdout);

    char ans[16];
    if (!fgets(ans, sizeof(ans), stdin)) return 0;
    ans[strcspn(ans, "\n")] = 0;
    if (strcmp(ans, "yes") != 0) {
        printf("Cancelled.\n");
        return 0;
    }

    long total = 0;
    printf("\nRemoving backup files (backup_*):\n");
    // We remove files with suffix matching by scanning current dir
    DIR *d = opendir(".");
    if (d) {
        struct dirent *ent;
        while ((ent = readdir(d))) {
            if (strncmp(ent->d_name, "backup_", 7) == 0 ||
                strstr(ent->d_name, ".tmp") != NULL) {
                struct stat st;
                if (stat(ent->d_name, &st) == 0) {
                    total += st.st_size;
                    remove(ent->d_name);
                    printf("  Deleted: %s (%ld bytes)\n", ent->d_name, (long)st.st_size);
                }
            }
        }
        closedir(d);
    }
    printf("\nClean complete. Total freed: %ld bytes (%.2f KB)\n",
           total, total/1024.0);
    printf("Press Enter to exit...");
    fflush(stdout);
    getchar();
    printf("[DiskCleaner] Closed.\n");
    return 0;
}
