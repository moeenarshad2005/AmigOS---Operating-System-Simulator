// tasks/encryptor.c  — XOR file encrypt/decrypt
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void xor_file(const char *src, const char *dst, const char *key) {
    FILE *in  = fopen(src, "rb");
    FILE *out = fopen(dst, "wb");
    if (!in)  { perror("input");  return; }
    if (!out) { perror("output"); fclose(in); return; }
    int    klen = (int)strlen(key);
    int    ch, ki = 0;
    while ((ch = fgetc(in)) != EOF) {
        fputc(ch ^ key[ki % klen], out);
        ki++;
    }
    fclose(in); fclose(out);
    printf("Done: %s → %s (key='%s')\n", src, dst, key);
}

int main(void) {
    printf("╔══════════════════════════════════════════════╗\n");
    printf("║           FILE ENCRYPTOR (XOR)               ║\n");
    printf("║  enc <src> <dst> <key>   - encrypt file      ║\n");
    printf("║  dec <src> <dst> <key>   - decrypt (same op) ║\n");
    printf("║  exit                                        ║\n");
    printf("╚══════════════════════════════════════════════╝\n");

    char line[512];
    while (1) {
        printf("enc> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;
        if (strcmp(line, "exit") == 0) break;
        char cmd[8], src[200], dst[200], key[64];
        if (sscanf(line, "%7s %199s %199s %63s", cmd, src, dst, key) == 4) {
            xor_file(src, dst, key);
        } else {
            printf("Usage: enc <src> <dst> <key>\n");
        }
    }
    printf("[Encryptor] Closed.\n");
    return 0;
}
