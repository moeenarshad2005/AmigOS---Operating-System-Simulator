// tasks/file_manager.c
// Foreground task — a mini file manager.
// Handles: create, copy, move, delete, info, list
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <time.h>
#include <errno.h>

// ── helpers ──────────────────────────────────

void do_create(const char *path) {
    FILE *f = fopen(path, "w");
    if (f) { fclose(f); printf("Created: %s\n", path); }
    else   perror("create");
}

void do_copy(const char *src, const char *dst) {
    FILE *in  = fopen(src, "rb");
    FILE *out = fopen(dst, "wb");
    if (!in)  { perror("open src"); return; }
    if (!out) { perror("open dst"); fclose(in); return; }
    char buf[4096]; size_t n;
    while ((n = fread(buf, 1, sizeof(buf), in)) > 0)
        fwrite(buf, 1, n, out);
    fclose(in); fclose(out);
    printf("Copied %s → %s\n", src, dst);
}

void do_move(const char *src, const char *dst) {
    if (rename(src, dst) == 0) printf("Moved %s → %s\n", src, dst);
    else { perror("move"); }
}

void do_delete(const char *path) {
    if (remove(path) == 0) printf("Deleted: %s\n", path);
    else perror("delete");
}

void do_info(const char *path) {
    struct stat st;
    if (stat(path, &st) < 0) { perror("stat"); return; }
    char timebuf[64];
    strftime(timebuf, sizeof(timebuf), "%Y-%m-%d %H:%M:%S",
             localtime(&st.st_mtime));
    printf("Name   : %s\n", path);
    printf("Size   : %ld bytes\n", (long)st.st_size);
    printf("Modified: %s\n", timebuf);
    printf("Type   : %s\n", S_ISDIR(st.st_mode) ? "Directory" : "File");
    printf("Perms  : %o\n", (unsigned)(st.st_mode & 0777));
}

void do_list(const char *dir) {
    DIR *d = opendir(dir ? dir : ".");
    if (!d) { perror("opendir"); return; }
    struct dirent *ent;
    printf("Contents of '%s':\n", dir ? dir : ".");
    while ((ent = readdir(d)))
        if (ent->d_name[0] != '.') printf("  %s\n", ent->d_name);
    closedir(d);
}

void do_search(const char *dir, const char *pattern) {
    DIR *d = opendir(dir ? dir : ".");
    if (!d) { perror("opendir"); return; }
    struct dirent *ent;
    printf("Search '%s' in '%s':\n", pattern, dir ? dir : ".");
    while ((ent = readdir(d)))
        if (strstr(ent->d_name, pattern))
            printf("  Found: %s\n", ent->d_name);
    closedir(d);
}

int main(void) {
    printf("╔══════════════════════════════════════════╗\n");
    printf("║            FILE MANAGER                  ║\n");
    printf("║ create <f>  copy <s> <d>  move <s> <d>  ║\n");
    printf("║ delete <f>  info  <f>     list [dir]     ║\n");
    printf("║ search <dir> <pattern>    exit           ║\n");
    printf("╚══════════════════════════════════════════╝\n");

    char line[512];
    while (1) {
        printf("fm> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;

        char cmd[32], a[256], b[256];
        int  n = sscanf(line, "%31s %255s %255s", cmd, a, b);

        if      (strcmp(cmd, "exit")   == 0) break;
        else if (strcmp(cmd, "create") == 0 && n >= 2) do_create(a);
        else if (strcmp(cmd, "delete") == 0 && n >= 2) do_delete(a);
        else if (strcmp(cmd, "info")   == 0 && n >= 2) do_info(a);
        else if (strcmp(cmd, "list")   == 0)            do_list(n >= 2 ? a : NULL);
        else if (strcmp(cmd, "copy")   == 0 && n == 3) do_copy(a, b);
        else if (strcmp(cmd, "move")   == 0 && n == 3) do_move(a, b);
        else if (strcmp(cmd, "search") == 0 && n == 3) do_search(a, b);
        else printf("Unknown command or wrong args.\n");
    }
    printf("[FileManager] Closed.\n");
    return 0;
}
