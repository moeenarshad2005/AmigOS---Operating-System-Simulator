// tasks/log_gen.c
// Background task — generates log entries every few seconds.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

static volatile int g_running = 1;
void handle_sig(int s) { (void)s; g_running = 0; }

static const char *log_messages[] = {
    "INFO  Kernel heartbeat OK",
    "INFO  Memory check passed",
    "WARN  CPU usage above 70%",
    "INFO  Disk I/O normal",
    "INFO  Network interface up",
    "DEBUG Scheduler tick fired",
    "INFO  Process table synced",
    "WARN  Low disk space warning",
    "INFO  System clock synced",
    "DEBUG Context switch recorded",
};
#define MSG_COUNT 10

int main(void) {
    signal(SIGTERM, handle_sig);
    signal(SIGINT,  handle_sig);

    const char *logfile = "system.log";
    FILE *f = fopen(logfile, "a");
    if (!f) { perror("log open"); return 1; }

    printf("╔══════════════════════════════╗\n");
    printf("║       LOG GENERATOR          ║\n");
    printf("║  Writing to: system.log      ║\n");
    printf("╚══════════════════════════════╝\n");

    srand((unsigned)time(NULL));
    int entry = 0;
    while (g_running) {
        time_t now = time(NULL);
        char ts[32];
        strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", localtime(&now));
        const char *msg = log_messages[rand() % MSG_COUNT];
        fprintf(f, "[%s] [%s]\n", ts, msg);
        fflush(f);
        printf("  [%s] %s\n", ts, msg);
        fflush(stdout);
        entry++;
        sleep(3);
    }
    fclose(f);
    printf("[LogGen] Stopped after %d entries.\n", entry);
    return 0;
}
