// tasks/minesweeper.c
// Foreground task — classic minesweeper on a 9x9 grid with 10 mines.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define ROWS  9
#define COLS  9
#define MINES 10

static int board[ROWS][COLS];     // -1 = mine, else count of adjacent mines
static int revealed[ROWS][COLS];  // 0=hidden, 1=revealed, 2=flagged
static int mines_placed = 0;
static int cells_revealed = 0;

void place_mines(int avoid_r, int avoid_c) {
    srand((unsigned)time(NULL));
    int placed = 0;
    while (placed < MINES) {
        int r = rand() % ROWS;
        int c = rand() % COLS;
        if (board[r][c] == -1) continue;
        if (r == avoid_r && c == avoid_c) continue;
        board[r][c] = -1;
        placed++;
    }
    // Calculate adjacent counts
    for (int r = 0; r < ROWS; r++)
    for (int c = 0; c < COLS; c++) {
        if (board[r][c] == -1) continue;
        int cnt = 0;
        for (int dr = -1; dr <= 1; dr++)
        for (int dc = -1; dc <= 1; dc++) {
            int nr = r+dr, nc = c+dc;
            if (nr>=0 && nr<ROWS && nc>=0 && nc<COLS && board[nr][nc]==-1) cnt++;
        }
        board[r][c] = cnt;
    }
    mines_placed = 1;
}

void print_board(int show_all) {
    printf("\n   ");
    for (int c = 0; c < COLS; c++) printf(" %d", c);
    printf("\n   ");
    for (int c = 0; c < COLS; c++) printf("──");
    printf("\n");
    for (int r = 0; r < ROWS; r++) {
        printf("%2d|", r);
        for (int c = 0; c < COLS; c++) {
            if (show_all) {
                if (board[r][c] == -1) printf(" *");
                else if (board[r][c] == 0) printf("  ");
                else printf(" %d", board[r][c]);
            } else {
                if      (revealed[r][c] == 2) printf(" F");
                else if (revealed[r][c] == 0) printf(" .");
                else if (board[r][c]   == -1) printf(" *");
                else if (board[r][c]   ==  0) printf("  ");
                else                          printf(" %d", board[r][c]);
            }
        }
        printf("\n");
    }
    printf("Revealed: %d/%d  Mines: %d\n",
           cells_revealed, ROWS*COLS - MINES, MINES);
}

// Flood-fill reveal for empty cells
void reveal(int r, int c) {
    if (r<0||r>=ROWS||c<0||c>=COLS) return;
    if (revealed[r][c] != 0) return;
    revealed[r][c] = 1;
    cells_revealed++;
    if (board[r][c] == 0) {
        for (int dr=-1;dr<=1;dr++)
        for (int dc=-1;dc<=1;dc++)
            reveal(r+dr, c+dc);
    }
}

int main(void) {
    memset(board,    0, sizeof(board));
    memset(revealed, 0, sizeof(revealed));

    printf("╔═══════════════════════════════╗\n");
    printf("║         MINESWEEPER           ║\n");
    printf("║  r <row> <col> - reveal cell  ║\n");
    printf("║  f <row> <col> - flag cell    ║\n");
    printf("║  exit          - quit game    ║\n");
    printf("╚═══════════════════════════════╝\n");

    char line[64];
    int  first_move = 1;

    while (1) {
        print_board(0);
        printf("move> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;
        if (strcmp(line, "exit") == 0) break;

        char act; int row, col;
        if (sscanf(line, " %c %d %d", &act, &row, &col) != 3) {
            printf("Format: r <row> <col>  or  f <row> <col>\n"); continue;
        }
        if (row<0||row>=ROWS||col<0||col>=COLS) {
            printf("Out of bounds (0-%d, 0-%d)\n", ROWS-1, COLS-1); continue;
        }

        if (act == 'f') {
            revealed[row][col] = (revealed[row][col] == 2) ? 0 : 2;
            continue;
        }
        if (act != 'r') { printf("Use 'r' to reveal or 'f' to flag\n"); continue; }
        if (revealed[row][col] == 2) { printf("Cell is flagged. Unflag first.\n"); continue; }

        if (first_move) { place_mines(row, col); first_move = 0; }

        if (board[row][col] == -1) {
            print_board(1);
            printf("\n💥 BOOM! You hit a mine! Game over.\n");
            break;
        }
        reveal(row, col);
        if (cells_revealed == ROWS*COLS - MINES) {
            print_board(0);
            printf("\n🎉 YOU WIN! All safe cells revealed!\n");
            break;
        }
    }
    printf("[Minesweeper] Closed.\n");
    return 0;
}
