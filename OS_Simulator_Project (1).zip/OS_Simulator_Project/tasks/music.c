// tasks/music.c
// Background task — simulates music by printing track info
// and "playing" for a fixed duration using beep chars.
// In a real system with a sound driver this would play audio.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

static volatile int g_running = 1;
void handle_sig(int s) { (void)s; g_running = 0; }

static const char *playlist[] = {
    "Track 1 - Morning Breeze    [3:42]",
    "Track 2 - Midnight Drive    [4:15]",
    "Track 3 - Summer Rain       [2:58]",
    "Track 4 - Electric Dreams   [5:01]",
    "Track 5 - Quiet Storm       [3:33]",
};
#define TRACK_COUNT 5

int main(void) {
    signal(SIGTERM, handle_sig);
    signal(SIGINT,  handle_sig);

    printf("╔═══════════════════════════════════╗\n");
    printf("║         MUSIC PLAYER              ║\n");
    printf("║  (Background – runs automatically)║\n");
    printf("╚═══════════════════════════════════╝\n");

    int track = 0;
    while (g_running) {
        printf("\n♪ Now Playing: %s\n", playlist[track % TRACK_COUNT]);
        printf("  Progress: ");
        for (int i = 0; i < 20 && g_running; i++) {
            printf("█");
            fflush(stdout);
            sleep(1);
        }
        printf(" ✓\n");
        track++;
    }
    printf("\n[Music] Playback stopped.\n");
    return 0;
}
