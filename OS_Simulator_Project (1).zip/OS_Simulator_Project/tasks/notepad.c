// tasks/notepad.c
// Foreground task. User types text line by line.
// Every 5 lines it auto-saves to notepad_autosave.txt
// Uses a POSIX thread for the autosave timer.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#define AUTOSAVE_INTERVAL 60   // seconds
#define MAX_LINES 1000
#define MAX_LINE_LEN 512
#define SAVE_FILE "notepad_save.txt"

static char   g_lines[MAX_LINES][MAX_LINE_LEN];
static int    g_count   = 0;
static int    g_running = 1;
static pthread_mutex_t g_mutex = PTHREAD_MUTEX_INITIALIZER;

// ── autosave thread ──────────────────────────
void *autosave_thread(void *arg) {
    (void)arg;
    while (g_running) {
        sleep(AUTOSAVE_INTERVAL);
        pthread_mutex_lock(&g_mutex);
        FILE *f = fopen(SAVE_FILE, "w");
        if (f) {
            for (int i = 0; i < g_count; i++)
                fprintf(f, "%s\n", g_lines[i]);
            fclose(f);
            printf("\n[Notepad] Auto-saved %d lines to %s\n", g_count, SAVE_FILE);
        }
        pthread_mutex_unlock(&g_mutex);
    }
    return NULL;
}

int main(void) {
    printf("\n╔══════════════════════════════════════╗\n");
    printf("║            NOTEPAD                   ║\n");
    printf("║  Type text, press Enter each line.   ║\n");
    printf("║  Commands: :save  :load  :show  :exit ║\n");
    printf("║  Auto-saves every %ds to %-14s║\n", AUTOSAVE_INTERVAL, SAVE_FILE);
    printf("╚══════════════════════════════════════╝\n");

    pthread_t tid;
    pthread_create(&tid, NULL, autosave_thread, NULL);

    char line[MAX_LINE_LEN];
    while (1) {
        printf("> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;

        if (strcmp(line, ":exit") == 0) break;

        if (strcmp(line, ":save") == 0) {
            pthread_mutex_lock(&g_mutex);
            FILE *f = fopen(SAVE_FILE, "w");
            if (f) {
                for (int i = 0; i < g_count; i++)
                    fprintf(f, "%s\n", g_lines[i]);
                fclose(f);
                printf("[Notepad] Saved %d lines to %s\n", g_count, SAVE_FILE);
            }
            pthread_mutex_unlock(&g_mutex);
            continue;
        }

        if (strcmp(line, ":load") == 0) {
            pthread_mutex_lock(&g_mutex);
            FILE *f = fopen(SAVE_FILE, "r");
            if (f) {
                g_count = 0;
                while (g_count < MAX_LINES && fgets(g_lines[g_count], MAX_LINE_LEN, f)) {
                    g_lines[g_count][strcspn(g_lines[g_count], "\n")] = 0;
                    g_count++;
                }
                fclose(f);
                printf("[Notepad] Loaded %d lines.\n", g_count);
            } else printf("[Notepad] No save file found.\n");
            pthread_mutex_unlock(&g_mutex);
            continue;
        }

        if (strcmp(line, ":show") == 0) {
            pthread_mutex_lock(&g_mutex);
            printf("──── Document (%d lines) ────\n", g_count);
            for (int i = 0; i < g_count; i++)
                printf("%4d: %s\n", i + 1, g_lines[i]);
            printf("─────────────────────────────\n");
            pthread_mutex_unlock(&g_mutex);
            continue;
        }

        pthread_mutex_lock(&g_mutex);
        if (g_count < MAX_LINES)
            strncpy(g_lines[g_count++], line, MAX_LINE_LEN - 1);
        pthread_mutex_unlock(&g_mutex);
    }

    g_running = 0;
    pthread_join(tid, NULL);

    // Final save
    FILE *f = fopen(SAVE_FILE, "w");
    if (f) {
        for (int i = 0; i < g_count; i++) fprintf(f, "%s\n", g_lines[i]);
        fclose(f);
    }
    printf("[Notepad] Closed. File saved.\n");
    return 0;
}
