// tasks/print_sim.c
// Background task — simulates printing a file page by page.
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[]) {
    const char *filename = (argc >= 3) ? argv[2] : "notepad_save.txt";
    printf("╔══════════════════════════════╗\n");
    printf("║       PRINT SIMULATION       ║\n");
    printf("╚══════════════════════════════╝\n");
    printf("Printing file: %s\n\n", filename);

    FILE *f = fopen(filename, "r");
    if (!f) {
        // Print a demo if file doesn't exist
        printf("[Printer] File not found. Printing demo document...\n");
        const char *demo[] = {
            "==== DEMO DOCUMENT ====",
            "Line 1: Hello from NovOS Printer",
            "Line 2: This is a background print job.",
            "Line 3: Resources were pre-allocated.",
            "Line 4: Job complete.",
        };
        for (int i = 0; i < 5; i++) {
            printf("  Printing: %s\n", demo[i]);
            fflush(stdout);
            sleep(1);
        }
    } else {
        char line[256];
        int  page = 1, line_num = 0;
        printf("---- Page %d ----\n", page);
        while (fgets(line, sizeof(line), f)) {
            printf("  %s", line);
            fflush(stdout);
            usleep(300000);   // 0.3s per line
            line_num++;
            if (line_num % 20 == 0) printf("---- Page %d ----\n", ++page);
        }
        fclose(f);
    }
    printf("\n[Printer] Print job complete.\n");
    return 0;
}
