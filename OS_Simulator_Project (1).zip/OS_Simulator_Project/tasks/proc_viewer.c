// tasks/proc_viewer.c
// System task — shows running processes using /proc filesystem
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <signal.h>
#include <ctype.h>

static volatile int g_running = 1;
void handle_sig(int s) { (void)s; g_running = 0; }

void list_procs(void) {
    DIR *d = opendir("/proc");
    if (!d) return;
    struct dirent *ent;
    printf("\n  %-8s %-25s %-10s\n", "PID", "Name", "State");
    printf("  %-8s %-25s %-10s\n", "───────", "────────────────────────", "─────────");
    int count = 0;
    while ((ent = readdir(d)) && count < 30) {
        // /proc entries that are numbers are PIDs
        int is_pid = 1;
        for (char *p = ent->d_name; *p; p++)
            if (!isdigit((unsigned char)*p)) { is_pid = 0; break; }
        if (!is_pid) continue;

        char path[64], name[64] = "?", state[4] = "?";
        snprintf(path, sizeof(path), "/proc/%s/status", ent->d_name);
        FILE *f = fopen(path, "r");
        if (!f) continue;
        char line[128], key[32], val[64];
        while (fgets(line, sizeof(line), f)) {
            if (sscanf(line, "%31s %63[^\n]", key, val) == 2) {
                if (strcmp(key, "Name:") == 0) strncpy(name, val, 63);
                if (strcmp(key, "State:") == 0) strncpy(state, val, 3);
            }
        }
        fclose(f);
        printf("  %-8s %-25s %-10s\n", ent->d_name, name, state);
        count++;
    }
    printf("\n  (showing first %d processes)\n", count);
    closedir(d);
}

int main(void) {
    signal(SIGTERM, handle_sig);
    signal(SIGINT,  handle_sig);

    printf("╔═══════════════════════════════════════╗\n");
    printf("║        PROCESS VIEWER                 ║\n");
    printf("║  Press Enter to refresh, 'exit' quit  ║\n");
    printf("╚═══════════════════════════════════════╝\n");

    char buf[32];
    while (g_running) {
        list_procs();
        printf("\nPress Enter to refresh (or type 'exit'): ");
        fflush(stdout);
        if (!fgets(buf, sizeof(buf), stdin)) break;
        if (strncmp(buf, "exit", 4) == 0) break;
    }
    printf("[ProcViewer] Closed.\n");
    return 0;
}
