// tasks/ram_viewer.c
// System task — shows RAM and HDD usage from /proc/meminfo
// and also reads our OS shared resource table.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

static volatile int g_running = 1;
void handle_sig(int s) { (void)s; g_running = 0; }

void print_bar(const char *label, long used, long total) {
    int   pct  = total > 0 ? (int)(used * 40 / total) : 0;
    printf("  %-8s [", label);
    for (int i = 0; i < 40; i++) printf(i < pct ? "█" : "░");
    printf("] %ldMB / %ldMB  (%d%%)\n",
           used/1024, total/1024,
           total > 0 ? (int)(used * 100 / total) : 0);
}

void read_proc_meminfo(long *total_kb, long *free_kb, long *avail_kb) {
    *total_kb = *free_kb = *avail_kb = 0;
    FILE *f = fopen("/proc/meminfo", "r");
    if (!f) return;
    char key[64]; long val;
    while (fscanf(f, "%63s %ld kB\n", key, &val) == 2) {
        if (strcmp(key, "MemTotal:")     == 0) *total_kb = val;
        if (strcmp(key, "MemFree:")      == 0) *free_kb  = val;
        if (strcmp(key, "MemAvailable:") == 0) *avail_kb = val;
    }
    fclose(f);
}

int main(void) {
    signal(SIGTERM, handle_sig);
    signal(SIGINT,  handle_sig);

    printf("╔══════════════════════════════════════════╗\n");
    printf("║            RAM USAGE VIEWER              ║\n");
    printf("║  Updates every 2s. Press Ctrl+C to exit  ║\n");
    printf("╚══════════════════════════════════════════╝\n");

    while (g_running) {
        long total_kb, free_kb, avail_kb;
        read_proc_meminfo(&total_kb, &free_kb, &avail_kb);
        long used_kb = total_kb - avail_kb;

        printf("\033[H\033[2J");   // clear screen
        printf("╔══════════════════════════════════════════╗\n");
        printf("║            RAM USAGE VIEWER              ║\n");
        printf("╚══════════════════════════════════════════╝\n\n");
        printf("  System Memory:\n");
        print_bar("RAM", used_kb, total_kb);
        printf("\n  OS Simulator Memory (from args):\n");
        printf("  (Launch OS with RAM/HDD args to see OS-level usage)\n\n");
        printf("  Refreshing in 2 seconds... (Ctrl+C to exit)\n");
        fflush(stdout);
        sleep(2);
    }
    printf("[RAM Viewer] Closed.\n");
    return 0;
}
