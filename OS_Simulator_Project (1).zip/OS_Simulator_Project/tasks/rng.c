// tasks/rng.c  — Random number generator utility
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

int main(void) {
    srand((unsigned)time(NULL));
    printf("╔═════════════════════════════════════╗\n");
    printf("║      RANDOM NUMBER GENERATOR        ║\n");
    printf("║  Commands:                          ║\n");
    printf("║  rand <min> <max>  - random integer ║\n");
    printf("║  float             - random 0.0-1.0 ║\n");
    printf("║  roll <N>d<S>      - dice (e.g.2d6) ║\n");
    printf("║  list <N> <min> <max> - N numbers   ║\n");
    printf("║  exit                               ║\n");
    printf("╚═════════════════════════════════════╝\n");

    char line[128];
    while (1) {
        printf("rng> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;

        int a, b;
        if (strcmp(line, "exit") == 0) break;
        else if (strcmp(line, "float") == 0) {
            printf("%.6f\n", (double)rand() / RAND_MAX);
        } else if (sscanf(line, "rand %d %d", &a, &b) == 2) {
            if (a > b) { printf("min must be <= max\n"); continue; }
            printf("%d\n", a + rand() % (b - a + 1));
        } else if (sscanf(line, "list %d %d %d", &a, &b, &b) == 3) {
            // Reparsing cleanly
            int count, lo, hi;
            sscanf(line, "list %d %d %d", &count, &lo, &hi);
            for (int i = 0; i < count && i < 100; i++)
                printf("%d ", lo + rand() % (hi - lo + 1));
            printf("\n");
        } else if (strncmp(line, "roll ", 5) == 0) {
            int dice, sides;
            if (sscanf(line + 5, "%dd%d", &dice, &sides) == 2) {
                int total = 0;
                printf("Rolling %dd%d: ", dice, sides);
                for (int i = 0; i < dice; i++) {
                    int r = 1 + rand() % sides;
                    printf("[%d]", r);
                    total += r;
                }
                printf(" = %d\n", total);
            } else printf("Format: roll 2d6\n");
        } else {
            printf("Unknown command.\n");
        }
    }
    printf("[RNG] Closed.\n");
    return 0;
}
