// tasks/snake.c  — Mini Snake game (foreground)
// Uses terminal raw mode for arrow-key input.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <termios.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>

#define ROWS 20
#define COLS 40
#define MAX_SNAKE 400

typedef struct { int r, c; } Point;

static Point snake[MAX_SNAKE];
static int   snake_len = 4;
static Point food;
static int   dir_r = 0, dir_c = 1;  // start moving right
static int   score = 0;
static int   running = 1;

static struct termios orig_term;

void restore_terminal(void) { tcsetattr(STDIN_FILENO, TCSANOW, &orig_term); }

void setup_terminal(void) {
    tcgetattr(STDIN_FILENO, &orig_term);
    atexit(restore_terminal);
    struct termios raw = orig_term;
    raw.c_lflag &= ~(ECHO | ICANON);
    raw.c_cc[VMIN]  = 0;
    raw.c_cc[VTIME] = 1;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);
}

void place_food(void) {
    srand((unsigned)time(NULL) + score);
    food.r = 1 + rand() % (ROWS - 2);
    food.c = 1 + rand() % (COLS - 2);
}

void draw(void) {
    printf("\033[H");   // cursor home
    // Top border
    printf("╔"); for(int c=0;c<COLS;c++) printf("═"); printf("╗\n");
    for (int r = 0; r < ROWS; r++) {
        printf("║");
        for (int c = 0; c < COLS; c++) {
            int is_snake = 0;
            for (int s = 0; s < snake_len; s++)
                if (snake[s].r == r && snake[s].c == c) { is_snake = 1; break; }
            if      (is_snake)         printf(r==snake[0].r&&c==snake[0].c?"@":"o");
            else if (food.r==r&&food.c==c) printf("*");
            else                           printf(" ");
        }
        printf("║\n");
    }
    printf("╚"); for(int c=0;c<COLS;c++) printf("═"); printf("╝\n");
    printf("  Score: %d   WASD to move, Q to quit\n", score);
    fflush(stdout);
}

int main(void) {
    printf("\033[2J");  // clear screen
    setup_terminal();
    // Init snake in middle
    for (int i = 0; i < snake_len; i++) {
        snake[i].r = ROWS / 2;
        snake[i].c = COLS/2 - i;
    }
    place_food();

    while (running) {
        // Read input (non-blocking)
        char ch = 0;
        read(STDIN_FILENO, &ch, 1);
        if      (ch=='w'||ch=='W') { dir_r=-1; dir_c=0; }
        else if (ch=='s'||ch=='S') { dir_r= 1; dir_c=0; }
        else if (ch=='a'||ch=='A') { dir_r=0; dir_c=-1; }
        else if (ch=='d'||ch=='D') { dir_r=0; dir_c= 1; }
        else if (ch=='q'||ch=='Q') break;

        // Move snake
        Point new_head = { snake[0].r + dir_r, snake[0].c + dir_c };

        // Wall collision
        if (new_head.r<0||new_head.r>=ROWS||new_head.c<0||new_head.c>=COLS) break;

        // Self collision
        for (int i = 0; i < snake_len-1; i++)
            if (snake[i].r==new_head.r && snake[i].c==new_head.c) { running=0; break; }
        if (!running) break;

        // Shift body
        memmove(&snake[1], &snake[0], sizeof(Point)*(MAX_SNAKE-1));
        snake[0] = new_head;

        // Eat food
        if (new_head.r==food.r && new_head.c==food.c) {
            score++; snake_len++; place_food();
        }

        draw();
        usleep(150000);   // 150ms per frame
    }

    restore_terminal();
    printf("\n\nGame Over! Final Score: %d\n", score);
    printf("[Snake] Closed.\n");
    return 0;
}
