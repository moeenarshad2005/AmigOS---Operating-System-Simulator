// tasks/sysinfo.c — System information viewer
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/utsname.h>
#include <sys/sysinfo.h>

void print_cpu_info(void) {
    FILE *f = fopen("/proc/cpuinfo", "r");
    if (!f) { printf("  CPU info unavailable\n"); return; }
    char line[256], model[256] = "Unknown";
    int  cores = 0;
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "model name", 10) == 0) {
            char *colon = strchr(line, ':');
            if (colon) strncpy(model, colon+2, 255);
            model[strcspn(model, "\n")] = 0;
        }
        if (strncmp(line, "processor", 9) == 0) cores++;
    }
    fclose(f);
    printf("  CPU    : %s\n", model);
    printf("  Cores  : %d\n", cores);
}

int main(void) {
    printf("╔═══════════════════════════════════════╗\n");
    printf("║           SYSTEM INFORMATION          ║\n");
    printf("╚═══════════════════════════════════════╝\n\n");

    // OS info
    struct utsname uts;
    uname(&uts);
    printf("  OS     : %s %s\n", uts.sysname, uts.release);
    printf("  Host   : %s\n",    uts.nodename);
    printf("  Arch   : %s\n\n",  uts.machine);

    // CPU
    print_cpu_info();
    printf("\n");

    // Memory
    struct sysinfo si;
    sysinfo(&si);
    long total_mb = si.totalram * si.mem_unit / (1024*1024);
    long free_mb  = si.freeram  * si.mem_unit / (1024*1024);
    printf("  RAM    : %ldMB total, %ldMB free\n", total_mb, free_mb);
    printf("  Uptime : %ld hours %ld min\n",
           si.uptime/3600, (si.uptime%3600)/60);
    printf("  Procs  : %d running\n\n", si.procs);

    printf("Press Enter to close...");
    fflush(stdout);
    getchar();
    printf("[SysInfo] Closed.\n");
    return 0;
}
