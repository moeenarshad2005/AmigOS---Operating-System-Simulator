// tasks/text_search.c
// Foreground task — grep-like text search in files
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void search_file(const char *filename, const char *pattern, int case_ins) {
    FILE *f = fopen(filename, "r");
    if (!f) { printf("Cannot open: %s\n", filename); return; }

    char line[1024];
    int  lineno = 0, found = 0;
    printf("Searching for '%s' in '%s':\n", pattern, filename);
    printf("─────────────────────────────────────────\n");

    while (fgets(line, sizeof(line), f)) {
        lineno++;
        // case-insensitive check: convert both to lower
        char low_line[1024], low_pat[256];
        if (case_ins) {
            for (int i = 0; line[i]; i++)
                low_line[i] = (char)((line[i]>='A'&&line[i]<='Z') ? line[i]+32 : line[i]);
            low_line[strlen(line)] = 0;
            for (int i = 0; pattern[i]; i++)
                low_pat[i] = (char)((pattern[i]>='A'&&pattern[i]<='Z') ? pattern[i]+32 : pattern[i]);
            low_pat[strlen(pattern)] = 0;
            if (strstr(low_line, low_pat)) {
                printf("%4d: %s", lineno, line);
                found++;
            }
        } else {
            if (strstr(line, pattern)) {
                printf("%4d: %s", lineno, line);
                found++;
            }
        }
    }
    fclose(f);
    printf("─────────────────────────────────────────\n");
    printf("Found %d match(es) in %d lines.\n", found, lineno);
}

int main(void) {
    printf("╔══════════════════════════════════════════╗\n");
    printf("║            TEXT SEARCH                   ║\n");
    printf("║  search <file> <pattern>                 ║\n");
    printf("║  isearch <file> <pattern>  (case-insens) ║\n");
    printf("║  exit                                    ║\n");
    printf("╚══════════════════════════════════════════╝\n");

    char line[512];
    while (1) {
        printf("search> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;
        if (strcmp(line, "exit") == 0) break;

        char cmd[16], file[256], pattern[256];
        int n = sscanf(line, "%15s %255s %255s", cmd, file, pattern);
        if (n == 3) {
            int ci = (strcmp(cmd, "isearch") == 0);
            search_file(file, pattern, ci);
        } else {
            printf("Usage: search <file> <pattern>\n");
        }
    }
    printf("[TextSearch] Closed.\n");
    return 0;
}
