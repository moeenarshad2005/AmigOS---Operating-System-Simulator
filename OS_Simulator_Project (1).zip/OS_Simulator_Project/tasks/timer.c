// tasks/timer.c  — countdown timer / alarm
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>

typedef struct { int seconds; char label[128]; } TimerArgs;

void *run_timer(void *arg) {
    TimerArgs *t = (TimerArgs *)arg;
    printf("[Timer] '%s' started for %d seconds\n", t->label, t->seconds);
    for (int i = t->seconds; i > 0; i--) {
        printf("\r  [%s] %3d seconds remaining... ", t->label, i);
        fflush(stdout);
        sleep(1);
    }
    printf("\n\n🔔 ALARM! '%s' timer done!\a\n\n", t->label);
    free(t);
    return NULL;
}

int main(void) {
    printf("╔══════════════════════════════════════╗\n");
    printf("║           TIMER / ALARM              ║\n");
    printf("║  set <seconds> <label>               ║\n");
    printf("║  Example: set 10 coffee break        ║\n");
    printf("║  exit - quit                         ║\n");
    printf("╚══════════════════════════════════════╝\n");

    char line[256];
    while (1) {
        printf("timer> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;
        if (strcmp(line, "exit") == 0) break;

        int secs;
        char label[128] = "Timer";
        if (sscanf(line, "set %d %127[^\n]", &secs, label) >= 1) {
            if (secs <= 0) { printf("Seconds must be positive.\n"); continue; }
            TimerArgs *ta = malloc(sizeof(TimerArgs));
            ta->seconds = secs;
            strncpy(ta->label, label, 127);
            pthread_t tid;
            pthread_create(&tid, NULL, run_timer, ta);
            pthread_detach(tid);
            printf("[Timer] Set '%s' for %d seconds (running in background)\n",
                   label, secs);
        } else {
            printf("Usage: set <seconds> <label>\n");
        }
    }
    printf("[Timer] Closed.\n");
    return 0;
}
