// tasks/word_count.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void count_file(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) { perror("open"); return; }
    long lines=0, words=0, chars=0;
    int  in_word = 0;
    int  ch;
    while ((ch = fgetc(f)) != EOF) {
        chars++;
        if (ch == '\n') lines++;
        if (isspace(ch)) in_word = 0;
        else if (!in_word) { in_word=1; words++; }
    }
    fclose(f);
    printf("File   : %s\n", path);
    printf("Lines  : %ld\nWords  : %ld\nChars  : %ld\n", lines, words, chars);
}

int main(void) {
    printf("╔════════════════════════════╗\n");
    printf("║        WORD COUNT          ║\n");
    printf("║  wc <filename>  or  exit   ║\n");
    printf("╚════════════════════════════╝\n");
    char line[256];
    while (1) {
        printf("wc> ");
        fflush(stdout);
        if (!fgets(line, sizeof(line), stdin)) break;
        line[strcspn(line, "\n")] = 0;
        if (strcmp(line, "exit") == 0) break;
        char cmd[8], fname[240];
        if (sscanf(line, "%7s %239s", cmd, fname) == 2 && strcmp(cmd,"wc")==0)
            count_file(fname);
        else
            printf("Usage: wc <filename>\n");
    }
    printf("[WordCount] Closed.\n");
    return 0;
}
